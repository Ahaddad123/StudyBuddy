﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : Form
    {
        public $safeitemname$()
        {
            InitializeComponent();
            this.MaximumSize = new System.Drawing.Size(1920, 1080);
            this.Size = new System.Drawing.Size(1920, 1080);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void butAddAssig_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
}
